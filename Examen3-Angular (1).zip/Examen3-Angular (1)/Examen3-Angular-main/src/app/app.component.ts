import { Component } from '@angular/core';

@Component({
  selector: 'app-proveedores',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'contabilidad-UIA';
}
